<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::post('login', 'AuthController@login');

Route::get('empresas-mostrar/{empresa_id}', 'EmpresaController@mostrar');
Route::get('empresas-listar', 'EmpresaController@listar');
Route::get('empresas-listar-habilitados', 'EmpresaController@listarHabilitados');
Route::resource('usuarios', 'UsuarioController');
Route::resource('empresas', 'EmpresaController');
Route::resource('oferta-demandas', 'OfertaDemandaController');
Route::resource('participantes', 'ParticipanteController');
Route::resource('rubros', 'RubroController');
Route::resource('horarios', 'HorarioController');
Route::resource('horarios-ocupados', 'HorarioOcupadoController');
Route::resource('mesas', 'MesaController');
Route::resource('reuniones', 'ReunionController');
Route::resource('agendas', 'AgendaController');
Route::resource('evaluaciones-generales', 'EvaluacionGeneralController');
Route::resource('evaluacion-reuniones', 'EvaluacionReunionController');
Route::resource('noticias', 'NoticiaController');
Route::get('evaluacion-registrada/{empresa_id}', 'EvaluacionGeneralController@registrado');
Route::get('empresa/{empresa_id}/participantes', 'EmpresaController@participantes');
Route::get('horarios-disponibles/{empresa_solicitante_id}/{empresa_demandada_id}', 'EmpresaController@horariosDisponibles');
Route::get('mis-horarios-ocupados/{empresa_id}', 'EmpresaController@horariosOcupados');
Route::get('mis-reuniones/{empresa_id}', 'EmpresaController@misReuniones');
Route::post('buscar-empresas', 'EmpresaController@buscar');
Route::get('solicitudes-salientes/{empresa_id}', 'AgendaController@solicitudesSalientes');
Route::get('solicitudes-entrantes/{empresa_id}', 'AgendaController@solicitudesEntrantes');
Route::get('mesas-disponibles/{horario_id}', 'AgendaController@mesasDisponibles');
Route::post('cambiar-estado', 'AgendaController@cambiarEstado');
Route::get('empresa-logo/{empresa_id}', 'EmpresaController@logo');
Route::get('usuario-logo', 'UsuarioController@logo');
Route::get('load-logo/{tipo}', 'UsuarioController@loadLogo');

Route::get('evaluacion-reunion-registrada/{reunion_id}/{empresa_id}/', 'EvaluacionReunionController@registrado');
Route::get('reporte-general/{parametro}', 'EvaluacionGeneralController@reporteGeneral');
Route::get('reporte-reunion/{parametro}', 'EvaluacionReunionController@reporteReunion');

Route::post('cambiar-logo/{empresa_id}', 'EmpresaController@cambiarLogo');
Route::get('mostrar-logo/{logo_path}', 'EmpresaController@mostrarLogo');

Route::post('cancelar-cita/{agenda_id}', 'AgendaController@cancelarCita');

Route::post('cambiar-password/{usuario_id}', 'AuthController@cambiarPassword');
Route::get('reset-password/{usuario_id}', 'UsuarioController@resetPassword');
Route::get('comentarios-generales', 'EvaluacionGeneralController@comentarios');
Route::get('comentarios-reuniones', 'EvaluacionReunionController@comentarios');

Route::get('generar-backup', 'BackupController@generarBackup');


Route::post('update-horario-ocupado', 'HorarioOcupadoController@updateHorarioOcupado');
Route::post('agendar', 'EmpresaController@agendar');


Route::get('habilitar/{empresa_id}', 'EmpresaController@habilitar');
Route::get('voucher/{voucher}', 'EmpresaController@voucher');
Route::post('subir-comprobante/{empresa_id}', 'EmpresaController@subirComprobante');

Route::get('mi-lista-habilitados/{empresa_id}', 'EmpresaController@miListaHabilitados');
Route::post('buscar-mi-lista-habilitados', 'EmpresaController@buscarMiListaHabilitados');
Route::get('agendas', 'EmpresaController@agendas');

Route::get('excel-general', 'EvaluacionGeneralController@excelGeneral');
Route::get('excel-reunion', 'EvaluacionReunionController@excelReunion');

Route::get('ofertas', 'OfertaDemandaController@ofertas');
Route::get('demandas', 'OfertaDemandaController@demandas');


Route::get('producto-ofertas/{empresa_id}', 'OfertaDemandaController@productoOfertas');
Route::get('servicio-ofertas/{empresa_id}', 'OfertaDemandaController@servicioOfertas');
Route::get('producto-demandas/{empresa_id}', 'OfertaDemandaController@productoDemandas');
Route::get('servicio-demandas/{empresa_id}', 'OfertaDemandaController@servicioDemandas');
Route::post('upload-voucher/{empresa_id}', 'EmpresaController@uploadVoucher');
Route::post('con-material/{empresa_id}', 'EmpresaController@conMaterial');


Route::get('mis-ofertas-demandas/{empresa_id}', 'OfertaDemandaController@ofertasDemandas');
Route::post('set-usuario', 'AuthController@setUsuario');
Route::get('administradores', 'UsuarioController@administradores');
Route::post('search-administradores', 'UsuarioController@searchAdministradores');

Route::post('agendas-mesa', 'ReunionController@agendasMesa');

Route::post('upload-rubros', 'RubroController@upload');

Route::get('paises', 'PaisController@index');
Route::post('paises', 'PaisController@store');


Route::post('rueda-habilitar', 'RuedaController@habilitar');
Route::post('rueda-deshabilitar', 'RuedaController@deshabilitar');
Route::get('rueda-mostrar', 'RuedaController@mostrar');
